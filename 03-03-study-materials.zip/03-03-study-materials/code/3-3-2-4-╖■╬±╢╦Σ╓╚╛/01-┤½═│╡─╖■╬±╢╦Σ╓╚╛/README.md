# 传统的服务端渲染

## 运行说明

```sh
npm install

node index.js
```
